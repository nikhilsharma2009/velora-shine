import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, Mail } from 'lucide-react';

const col = 'text-sm text-ivory/70 transition-colors hover:text-gold';

export default function Footer() {
  return (
    <footer className="bg-charcoal text-ivory">
      <div className="container-x grid gap-12 py-16 md:grid-cols-4">
        <div className="md:col-span-1">
          <p className="font-serif text-2xl tracking-[0.4em]">VELORA</p>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-ivory/60">
            Modern luxury gold and diamond jewellery, designed to be lived in.
          </p>
          <div className="mt-6 flex gap-4 text-ivory/70">
            <a href="https://instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram" className="hover:text-gold"><Instagram size={18} /></a>
            <a href="https://facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook" className="hover:text-gold"><Facebook size={18} /></a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter" className="hover:text-gold"><Twitter size={18} /></a>
            <a href="mailto:care@velora.example" aria-label="Email" className="hover:text-gold"><Mail size={18} /></a>
          </div>
        </div>
        <div>
          <h4 className="eyebrow !text-gold">Shop</h4>
          <ul className="mt-5 space-y-3">
            <li><Link className={col} to="/shop">All Jewellery</Link></li>
            <li><Link className={col} to="/shop?category=Rings">Rings</Link></li>
            <li><Link className={col} to="/shop?category=Necklaces">Necklaces</Link></li>
            <li><Link className={col} to="/shop?category=Earrings">Earrings</Link></li>
            <li><Link className={col} to="/shop?category=Bracelets">Bracelets</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="eyebrow !text-gold">Collections</h4>
          <ul className="mt-5 space-y-3">
            <li><Link className={col} to="/shop?gender=Women">For Her</Link></li>
            <li><Link className={col} to="/shop?gender=Men">For Him</Link></li>
            <li><Link className={col} to="/shop?sort=newest">New Arrivals</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="eyebrow !text-gold">Account</h4>
          <ul className="mt-5 space-y-3">
            <li><Link className={col} to="/account">My Account</Link></li>
            <li><Link className={col} to="/account?tab=orders">Orders</Link></li>
            <li><Link className={col} to="/account?tab=wishlist">Wishlist</Link></li>
            <li><Link className={col} to="/cart">Cart</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-ivory/10">
        <div className="container-x flex flex-col items-center justify-between gap-2 py-6 text-xs text-ivory/50 sm:flex-row">
          <p>© {new Date().getFullYear()} VELORA. All rights reserved.</p>
          <p>Hallmarked gold · Certified diamonds · Insured delivery</p>
        </div>
      </div>
    </footer>
  );
}
