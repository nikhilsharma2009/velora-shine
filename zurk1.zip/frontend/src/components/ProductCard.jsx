import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag } from 'lucide-react';
import { formatPrice, FALLBACK_IMG } from '../utils/format';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';

export default function ProductCard({ product }) {
  const wishlist = useWishlist();
  const cart = useCart();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const liked = wishlist.has(product.id);
  const needsSize = product.sizes.length > 0;
  const outOfStock = product.stock !== null && product.stock <= 0;

  const onWish = (e) => {
    e.preventDefault();
    const added = wishlist.toggle(product);
    toast.success(added ? 'Added to wishlist' : 'Removed from wishlist');
  };

  const onQuickAdd = async (e) => {
    e.preventDefault();
    if (needsSize) return; // sizes require choosing on the product page (link handles navigation)
    setBusy(true);
    try {
      await cart.addItem(product, { quantity: 1 });
      toast.success('Added to cart');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <article className="group">
      <Link to={`/product/${product.id}`} className="block">
        <div className="relative aspect-[4/5] overflow-hidden bg-beige">
          <img
            src={product.images[0] || FALLBACK_IMG}
            alt={product.name}
            loading="lazy"
            onError={(e) => { e.currentTarget.src = FALLBACK_IMG; }}
            className="h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-105"
          />
          <div className="absolute left-3 top-3 flex gap-2">
            {product.isNew && <span className="bg-ivory px-2.5 py-1 text-[10px] uppercase tracking-[0.18em]">New</span>}
            {outOfStock && <span className="bg-charcoal px-2.5 py-1 text-[10px] uppercase tracking-[0.18em] text-ivory">Sold out</span>}
          </div>
          <button
            onClick={onWish}
            aria-label={liked ? 'Remove from wishlist' : 'Add to wishlist'}
            className="absolute right-3 top-3 grid h-9 w-9 place-items-center bg-ivory/90 transition hover:bg-gold"
          >
            <Heart size={16} className={liked ? 'fill-charcoal' : ''} />
          </button>
          {!outOfStock && (
            <span
              onClick={needsSize ? undefined : onQuickAdd}
              role="button"
              className={`absolute inset-x-0 bottom-0 flex translate-y-full items-center justify-center gap-2 bg-charcoal/95 py-3 text-[11px] uppercase tracking-[0.2em] text-ivory transition-transform duration-300 group-hover:translate-y-0 ${busy ? 'opacity-70' : ''}`}
            >
              <ShoppingBag size={14} /> {needsSize ? 'Select size' : busy ? 'Adding…' : 'Quick add'}
            </span>
          )}
        </div>
        <div className="mt-4 text-center">
          <p className="text-[10px] uppercase tracking-[0.2em] text-charcoal/50">{product.category}</p>
          <h3 className="mt-1 font-serif text-lg leading-snug">{product.name}</h3>
          <p className="mt-1 text-sm text-gold-dark">{formatPrice(product.price)}</p>
        </div>
      </Link>
    </article>
  );
}
