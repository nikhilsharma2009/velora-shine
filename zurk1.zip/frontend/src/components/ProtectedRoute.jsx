import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Spinner } from './StateViews';

export default function ProtectedRoute({ children, adminOnly = false }) {
  const { isAuthenticated, isAdmin, loading } = useAuth();
  const location = useLocation();

  if (loading) return <Spinner label="Checking your session" />;
  if (!isAuthenticated) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  if (adminOnly && !isAdmin) {
    return (
      <div className="container-x py-24 text-center">
        <h1 className="text-4xl">Access restricted</h1>
        <p className="mt-3 text-sm text-charcoal/70">This area is only available to VELORA administrators.</p>
      </div>
    );
  }
  return children;
}
