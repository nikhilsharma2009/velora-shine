import { Link } from 'react-router-dom';
import { AlertCircle, PackageOpen } from 'lucide-react';

export function Spinner({ label = 'Loading' }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-20 text-charcoal/60" role="status">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-beige border-t-gold" />
      <span className="text-xs uppercase tracking-[0.2em]">{label}</span>
    </div>
  );
}

export function ProductGridSkeleton({ count = 8 }) {
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="animate-pulse">
          <div className="aspect-[4/5] bg-beige" />
          <div className="mt-4 h-3 w-3/4 bg-beige" />
          <div className="mt-2 h-3 w-1/3 bg-beige" />
        </div>
      ))}
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center py-20 text-center" role="alert">
      <AlertCircle className="mb-4 text-gold-dark" size={36} strokeWidth={1.2} />
      <h3 className="text-2xl">Something went wrong</h3>
      <p className="mt-2 text-sm text-charcoal/70">{message}</p>
      {onRetry && <button onClick={onRetry} className="btn-dark mt-6">Try again</button>}
    </div>
  );
}

export function EmptyState({ title, message, actionLabel, actionTo, onAction }) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center py-20 text-center">
      <PackageOpen className="mb-4 text-gold-dark" size={36} strokeWidth={1.2} />
      <h3 className="text-2xl">{title}</h3>
      {message && <p className="mt-2 text-sm text-charcoal/70">{message}</p>}
      {actionTo && <Link to={actionTo} className="btn-dark mt-6">{actionLabel}</Link>}
      {onAction && <button onClick={onAction} className="btn-dark mt-6">{actionLabel}</button>}
    </div>
  );
}
