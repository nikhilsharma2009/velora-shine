import { useEffect, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Heart, Menu, Search, ShoppingBag, User, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

const links = [
  { to: '/shop', label: 'Shop All' },
  { to: '/shop?gender=Women', label: 'Women' },
  { to: '/shop?gender=Men', label: 'Men' },
  { to: '/#story', label: 'Our Story' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState('');
  const [scrolled, setScrolled] = useState(false);
  const { isAuthenticated, isAdmin, user, logout } = useAuth();
  const cart = useCart();
  const wishlist = useWishlist();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const submitSearch = (e) => {
    e.preventDefault();
    navigate(`/shop${q.trim() ? `?search=${encodeURIComponent(q.trim())}` : ''}`);
    setSearchOpen(false);
    setOpen(false);
    setQ('');
  };

  const iconBtn = 'relative grid h-10 w-10 place-items-center transition-colors hover:text-gold-dark';
  const badge = 'absolute right-0.5 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-gold px-1 text-[10px] font-medium text-charcoal';

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-ivory/95 shadow-sm backdrop-blur' : 'bg-ivory'}`}>
      <div className="container-x flex h-[72px] items-center justify-between">
        <button className="md:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu size={22} /></button>

        <nav className="hidden items-center gap-9 md:flex">
          {links.map((l) => (
            <NavLink key={l.label} to={l.to} className="text-[11px] uppercase tracking-[0.2em] transition-colors hover:text-gold-dark">
              {l.label}
            </NavLink>
          ))}
        </nav>

        <Link to="/" className="absolute left-1/2 -translate-x-1/2 font-serif text-2xl tracking-[0.4em] md:text-[28px]">VELORA</Link>

        <div className="flex items-center">
          <button className={iconBtn} onClick={() => setSearchOpen((s) => !s)} aria-label="Search"><Search size={19} /></button>
          <Link to={isAuthenticated ? '/account' : '/login'} className={`${iconBtn} hidden sm:grid`} aria-label="Account"><User size={19} /></Link>
          <Link to="/account?tab=wishlist" className={`${iconBtn} hidden sm:grid`} aria-label="Wishlist">
            <Heart size={19} />
            {wishlist.count > 0 && <span className={badge}>{wishlist.count}</span>}
          </Link>
          <Link to="/cart" className={iconBtn} aria-label="Cart">
            <ShoppingBag size={19} />
            {cart.count > 0 && <span className={badge}>{cart.count}</span>}
          </Link>
        </div>
      </div>

      {searchOpen && (
        <form onSubmit={submitSearch} className="animate-fade-in border-t border-beige bg-ivory">
          <div className="container-x flex items-center gap-3 py-3">
            <Search size={18} className="text-charcoal/50" />
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search rings, necklaces, earrings…"
              className="flex-1 bg-transparent py-2 text-sm outline-none placeholder:text-charcoal/40" />
            <button type="button" onClick={() => setSearchOpen(false)} aria-label="Close search"><X size={18} /></button>
          </div>
        </form>
      )}

      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-charcoal/50" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 h-full w-4/5 max-w-xs animate-fade-in bg-ivory p-6">
            <div className="flex items-center justify-between">
              <span className="font-serif text-xl tracking-[0.35em]">VELORA</span>
              <button onClick={() => setOpen(false)} aria-label="Close menu"><X size={22} /></button>
            </div>
            <nav className="mt-10 flex flex-col gap-6">
              {links.map((l) => (
                <Link key={l.label} to={l.to} onClick={() => setOpen(false)} className="font-serif text-2xl">{l.label}</Link>
              ))}
              <hr className="border-beige" />
              {isAuthenticated ? (
                <>
                  <Link to="/account" onClick={() => setOpen(false)} className="text-sm uppercase tracking-[0.18em]">My Account ({user?.name?.split(' ')[0]})</Link>
                  <Link to="/account?tab=wishlist" onClick={() => setOpen(false)} className="text-sm uppercase tracking-[0.18em]">Wishlist</Link>
                  {isAdmin && <Link to="/admin" onClick={() => setOpen(false)} className="text-sm uppercase tracking-[0.18em]">Admin</Link>}
                  <button onClick={() => { logout(); setOpen(false); navigate('/'); }} className="text-left text-sm uppercase tracking-[0.18em]">Sign out</button>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setOpen(false)} className="text-sm uppercase tracking-[0.18em]">Sign in</Link>
                  <Link to="/register" onClick={() => setOpen(false)} className="text-sm uppercase tracking-[0.18em]">Create account</Link>
                </>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
