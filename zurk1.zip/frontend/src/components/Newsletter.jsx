import { useState } from 'react';
import { useToast } from '../context/ToastContext';

// There is no newsletter endpoint in the backend contract yet, so this validates the email and
// stores the subscription locally. Replace `subscribe` with an API call when the endpoint exists.
async function subscribe(email) {
  const key = 'velora_newsletter';
  const list = JSON.parse(localStorage.getItem(key) || '[]');
  if (list.includes(email)) throw new Error('You are already subscribed.');
  localStorage.setItem(key, JSON.stringify([...list, email]));
}

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const toast = useToast();

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) { toast.error('Please enter a valid email address.'); return; }
    setBusy(true);
    try {
      await subscribe(email);
      toast.success('Welcome to VELORA. Thank you for subscribing.');
      setEmail('');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="bg-charcoal py-20 text-ivory">
      <div className="container-x mx-auto max-w-2xl text-center">
        <p className="eyebrow !text-gold">The VELORA Letter</p>
        <h2 className="mt-4 text-4xl md:text-5xl">Be the first to know</h2>
        <p className="mt-4 text-sm text-ivory/70">Private previews, new collections and quiet notes on craft. No noise.</p>
        <form onSubmit={onSubmit} className="mt-8 flex flex-col gap-3 sm:flex-row">
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Your email address" aria-label="Email address"
            className="flex-1 border border-ivory/30 bg-transparent px-4 py-3.5 text-sm outline-none placeholder:text-ivory/40 focus:border-gold" />
          <button disabled={busy} className="btn-gold">{busy ? 'Subscribing…' : 'Subscribe'}</button>
        </form>
      </div>
    </section>
  );
}
