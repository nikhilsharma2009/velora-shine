import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Minus, Plus, Trash2 } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { formatPrice, FALLBACK_IMG } from '../utils/format';
import { EmptyState, ErrorState, Spinner } from '../components/StateViews';

export default function Cart() {
  const cart = useCart();
  const { isAuthenticated } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [pending, setPending] = useState(null);

  const run = async (id, fn) => {
    setPending(id);
    try { await fn(); } catch (e) { toast.error(e.message); } finally { setPending(null); }
  };

  if (cart.loading) return <Spinner label="Loading your cart" />;
  if (cart.error) return <ErrorState message={cart.error} onRetry={cart.reload} />;
  if (cart.items.length === 0) {
    return <EmptyState title="Your cart is empty" message="Discover pieces made to be worn every day." actionLabel="Continue shopping" actionTo="/shop" />;
  }

  const goCheckout = () => {
    if (!isAuthenticated) { navigate('/login', { state: { from: '/checkout' } }); return; }
    navigate('/checkout');
  };

  return (
    <div className="container-x py-12">
      <h1 className="text-center text-5xl">Shopping Cart</h1>
      <div className="mt-12 grid gap-12 lg:grid-cols-[1fr_380px]">
        <ul className="divide-y divide-beige border-y border-beige">
          {cart.items.map((item) => {
            const busy = pending === item.id;
            return (
              <li key={item.id} className={`flex gap-5 py-6 transition-opacity ${busy ? 'opacity-50' : ''}`}>
                <Link to={`/product/${item.productId}`} className="h-32 w-24 shrink-0 overflow-hidden bg-beige">
                  <img src={item.product.images[0] || FALLBACK_IMG} alt={item.product.name} className="h-full w-full object-cover" onError={(e) => { e.currentTarget.src = FALLBACK_IMG; }} />
                </Link>
                <div className="flex flex-1 flex-col justify-between">
                  <div className="flex justify-between gap-4">
                    <div>
                      <Link to={`/product/${item.productId}`} className="font-serif text-xl hover:text-gold-dark">{item.product.name}</Link>
                      {item.size && <p className="mt-1 text-xs uppercase tracking-[0.15em] text-charcoal/55">Size {item.size}</p>}
                      <p className="mt-1 text-sm text-charcoal/70">{formatPrice(item.product.price)}</p>
                    </div>
                    <p className="text-sm">{formatPrice(item.product.price * item.quantity)}</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="inline-flex items-center border border-charcoal/25">
                      <button disabled={busy || item.quantity <= 1} onClick={() => run(item.id, () => cart.updateQuantity(item.id, item.quantity - 1))} className="grid h-9 w-9 place-items-center hover:bg-beige disabled:opacity-40" aria-label="Decrease quantity"><Minus size={14} /></button>
                      <span className="w-9 text-center text-sm">{item.quantity}</span>
                      <button disabled={busy} onClick={() => run(item.id, () => cart.updateQuantity(item.id, item.quantity + 1))} className="grid h-9 w-9 place-items-center hover:bg-beige disabled:opacity-40" aria-label="Increase quantity"><Plus size={14} /></button>
                    </div>
                    <button disabled={busy} onClick={() => run(item.id, async () => { await cart.removeItem(item.id); toast.success('Removed from cart'); })}
                      className="flex items-center gap-2 text-xs uppercase tracking-[0.15em] text-charcoal/60 hover:text-red-700">
                      <Trash2 size={14} /> Remove
                    </button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>

        <aside className="h-fit border border-beige bg-white/40 p-7">
          <h2 className="text-2xl">Order summary</h2>
          <dl className="mt-6 space-y-3 text-sm">
            <div className="flex justify-between"><dt className="text-charcoal/70">Subtotal ({cart.count} item{cart.count > 1 ? 's' : ''})</dt><dd>{formatPrice(cart.subtotal)}</dd></div>
            <div className="flex justify-between"><dt className="text-charcoal/70">Shipping</dt><dd>Free</dd></div>
          </dl>
          <div className="mt-5 flex justify-between border-t border-beige pt-5 text-lg">
            <span className="font-serif text-xl">Subtotal</span><span>{formatPrice(cart.subtotal)}</span>
          </div>
          <p className="mt-2 text-xs text-charcoal/55">Final amount is confirmed by our server at checkout.</p>
          <button onClick={goCheckout} className="btn-dark mt-6 w-full">Proceed to checkout</button>
          <Link to="/shop" className="mt-4 block text-center text-xs uppercase tracking-[0.18em] text-charcoal/60 hover:text-gold-dark">Continue shopping</Link>
        </aside>
      </div>
    </div>
  );
}
