import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ChevronRight, Heart, Minus, Plus, ShieldCheck, Truck, RefreshCcw } from 'lucide-react';
import { fetchProduct, fetchProducts } from '../api/products';
import { useFetch } from '../utils/useFetch';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useToast } from '../context/ToastContext';
import { formatPrice, FALLBACK_IMG } from '../utils/format';
import { ErrorState, Spinner } from '../components/StateViews';
import ProductCard from '../components/ProductCard';

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const cart = useCart();
  const wishlist = useWishlist();
  const toast = useToast();

  const { data: product, loading, error, reload } = useFetch((signal) => fetchProduct(id, signal), [id]);
  const { data: all } = useFetch((signal) => fetchProducts({}, signal), []);

  const [activeImg, setActiveImg] = useState(0);
  const [size, setSize] = useState('');
  const [qty, setQty] = useState(1);
  const [busy, setBusy] = useState(false);
  const [sizeError, setSizeError] = useState(false);

  useEffect(() => { setActiveImg(0); setSize(''); setQty(1); setSizeError(false); }, [id]);

  if (loading) return <Spinner label="Loading piece" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!product) return null;

  const needsSize = product.sizes.length > 0;
  const outOfStock = product.stock !== null && product.stock <= 0;
  const maxQty = product.stock !== null ? Math.max(1, product.stock) : 10;
  const liked = wishlist.has(product.id);
  const images = product.images.length ? product.images : [FALLBACK_IMG];
  const related = (all || []).filter((p) => p.id !== product.id && p.category === product.category).slice(0, 4);

  const validate = () => {
    if (needsSize && !size) { setSizeError(true); toast.error('Please select a size.'); return false; }
    return true;
  };

  const addToCart = async (goToCart = false) => {
    if (!validate()) return;
    setBusy(true);
    try {
      await cart.addItem(product, { quantity: qty, size });
      toast.success('Added to cart');
      if (goToCart) navigate('/cart');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container-x py-10">
      <nav className="mb-8 flex items-center gap-2 text-xs text-charcoal/60">
        <Link to="/" className="hover:text-gold-dark">Home</Link><ChevronRight size={12} />
        <Link to="/shop" className="hover:text-gold-dark">Shop</Link><ChevronRight size={12} />
        <Link to={`/shop?category=${product.category}`} className="hover:text-gold-dark">{product.category}</Link>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
        <div className="flex flex-col-reverse gap-4 sm:flex-row">
          {images.length > 1 && (
            <div className="flex gap-3 sm:flex-col">
              {images.map((src, i) => (
                <button key={i} onClick={() => setActiveImg(i)} aria-label={`View image ${i + 1}`}
                  className={`h-20 w-16 shrink-0 overflow-hidden border bg-beige transition ${i === activeImg ? 'border-gold' : 'border-transparent opacity-70 hover:opacity-100'}`}>
                  <img src={src} alt="" className="h-full w-full object-cover" onError={(e) => { e.currentTarget.src = FALLBACK_IMG; }} />
                </button>
              ))}
            </div>
          )}
          <div className="aspect-[4/5] flex-1 overflow-hidden bg-beige">
            <img src={images[activeImg]} alt={product.name} className="h-full w-full object-cover animate-fade-in" key={activeImg}
              onError={(e) => { e.currentTarget.src = FALLBACK_IMG; }} />
          </div>
        </div>

        <div className="lg:py-4">
          <p className="eyebrow">{product.category}{product.material ? ` · ${product.material}` : ''}</p>
          <h1 className="mt-3 text-4xl leading-tight md:text-5xl">{product.name}</h1>
          <p className="mt-4 text-2xl text-gold-dark">{formatPrice(product.price)}</p>
          <p className="mt-1 text-xs text-charcoal/50">Inclusive of all taxes</p>

          <p className="mt-6 text-[15px] leading-relaxed text-charcoal/75">{product.description}</p>

          {needsSize && (
            <div className="mt-8">
              <div className="mb-3 flex items-center justify-between">
                <span className="label !mb-0">Size {size && <span className="text-charcoal">· {size}</span>}</span>
                {sizeError && <span className="text-xs text-red-700">Please choose a size</span>}
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button key={s} onClick={() => { setSize(s); setSizeError(false); }}
                    className={`min-w-12 border px-4 py-2.5 text-sm transition ${size === s ? 'border-charcoal bg-charcoal text-ivory' : 'border-charcoal/25 hover:border-gold'}`}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="mt-8">
            <span className="label">Quantity</span>
            <div className="inline-flex items-center border border-charcoal/25">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="grid h-11 w-11 place-items-center hover:bg-beige" aria-label="Decrease"><Minus size={16} /></button>
              <span className="w-10 text-center text-sm">{qty}</span>
              <button onClick={() => setQty((q) => Math.min(maxQty, q + 1))} className="grid h-11 w-11 place-items-center hover:bg-beige" aria-label="Increase"><Plus size={16} /></button>
            </div>
            {product.stock !== null && product.stock > 0 && product.stock <= 5 && (
              <p className="mt-2 text-xs text-gold-dark">Only {product.stock} left in stock</p>
            )}
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <button onClick={() => addToCart(false)} disabled={busy || outOfStock} className="btn-dark flex-1">
              {outOfStock ? 'Sold out' : busy ? 'Adding…' : 'Add to cart'}
            </button>
            <button onClick={() => addToCart(true)} disabled={busy || outOfStock} className="btn-outline flex-1">Buy now</button>
            <button
              onClick={() => toast.success(wishlist.toggle(product) ? 'Added to wishlist' : 'Removed from wishlist')}
              className={`grid h-[52px] w-full place-items-center border border-charcoal/25 transition hover:border-gold sm:w-[52px] ${liked ? 'bg-beige' : ''}`}
              aria-label={liked ? 'Remove from wishlist' : 'Add to wishlist'}>
              <Heart size={18} className={liked ? 'fill-charcoal' : ''} />
            </button>
          </div>

          <ul className="mt-10 space-y-4 border-t border-beige pt-8 text-sm text-charcoal/75">
            <li className="flex items-center gap-3"><ShieldCheck size={18} className="text-gold-dark" /> BIS hallmarked gold and certified diamonds</li>
            <li className="flex items-center gap-3"><Truck size={18} className="text-gold-dark" /> Free insured shipping across India</li>
            <li className="flex items-center gap-3"><RefreshCcw size={18} className="text-gold-dark" /> 15-day easy returns</li>
          </ul>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-24">
          <h2 className="mb-10 text-center text-4xl">You may also love</h2>
          <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
            {related.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </div>
  );
}
