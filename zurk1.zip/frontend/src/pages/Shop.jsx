import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { fetchProducts } from '../api/products';
import { useFetch } from '../utils/useFetch';
import ProductCard from '../components/ProductCard';
import { EmptyState, ErrorState, ProductGridSkeleton } from '../components/StateViews';

const CATEGORIES = ['Rings', 'Necklaces', 'Earrings', 'Bracelets'];
const GENDERS = ['Women', 'Men'];
const PRICE_RANGES = [
  { label: 'Under ₹25,000', min: 0, max: 25000 },
  { label: '₹25,000 – ₹50,000', min: 25000, max: 50000 },
  { label: '₹50,000 – ₹1,00,000', min: 50000, max: 100000 },
  { label: 'Over ₹1,00,000', min: 100000, max: Infinity },
];
const SORTS = [
  { value: 'featured', label: 'Featured' },
  { value: 'newest', label: 'Newest' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'name', label: 'Name: A to Z' },
];

export default function Shop() {
  const [params, setParams] = useSearchParams();
  const category = params.get('category') || '';
  const gender = params.get('gender') || '';
  const search = params.get('search') || '';
  const sort = params.get('sort') || 'featured';
  const range = params.get('range') || '';

  const [searchText, setSearchText] = useState(search);
  const [filtersOpen, setFiltersOpen] = useState(false);
  useEffect(() => setSearchText(search), [search]);

  const { data, loading, error, reload } = useFetch((signal) => fetchProducts({}, signal), []);

  const setParam = (key, value) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value); else next.delete(key);
    setParams(next, { replace: true });
  };
  const clearAll = () => setParams({}, { replace: true });

  const filtered = useMemo(() => {
    let list = [...(data || [])];
    if (category) list = list.filter((p) => p.category === category);
    if (gender) list = list.filter((p) => p.gender === gender || p.gender === 'Unisex');
    if (range !== '') {
      const r = PRICE_RANGES[Number(range)];
      if (r) list = list.filter((p) => p.price >= r.min && p.price < r.max);
    }
    if (search) {
      const q = search.toLowerCase();
      list = list.filter((p) => [p.name, p.category, p.material, p.description].some((f) => f?.toLowerCase().includes(q)));
    }
    switch (sort) {
      case 'price-asc': list.sort((a, b) => a.price - b.price); break;
      case 'price-desc': list.sort((a, b) => b.price - a.price); break;
      case 'name': list.sort((a, b) => a.name.localeCompare(b.name)); break;
      case 'newest': list.sort((a, b) => (new Date(b.createdAt || 0) - new Date(a.createdAt || 0)) || (Number(b.isNew) - Number(a.isNew))); break;
      default: break;
    }
    return list;
  }, [data, category, gender, range, search, sort]);

  const hasFilters = category || gender || search || range !== '';

  const FilterBlock = ({ title, children }) => (
    <div className="border-b border-beige py-6">
      <h3 className="eyebrow mb-4">{title}</h3>
      <div className="flex flex-col gap-2.5 text-sm">{children}</div>
    </div>
  );
  const Radio = ({ checked, onChange, label }) => (
    <label className="flex cursor-pointer items-center gap-3">
      <span className={`grid h-4 w-4 place-items-center rounded-full border ${checked ? 'border-gold' : 'border-charcoal/40'}`}>
        {checked && <span className="h-2 w-2 rounded-full bg-gold" />}
      </span>
      <input type="radio" className="sr-only" checked={checked} onChange={onChange} />
      <span className={checked ? 'text-charcoal' : 'text-charcoal/70'}>{label}</span>
    </label>
  );

  const filters = (
    <>
      <FilterBlock title="Category">
        <Radio checked={!category} onChange={() => setParam('category', '')} label="All" />
        {CATEGORIES.map((c) => <Radio key={c} checked={category === c} onChange={() => setParam('category', c)} label={c} />)}
      </FilterBlock>
      <FilterBlock title="For">
        <Radio checked={!gender} onChange={() => setParam('gender', '')} label="Everyone" />
        {GENDERS.map((g) => <Radio key={g} checked={gender === g} onChange={() => setParam('gender', g)} label={g} />)}
      </FilterBlock>
      <FilterBlock title="Price">
        <Radio checked={range === ''} onChange={() => setParam('range', '')} label="Any price" />
        {PRICE_RANGES.map((r, i) => <Radio key={r.label} checked={range === String(i)} onChange={() => setParam('range', String(i))} label={r.label} />)}
      </FilterBlock>
    </>
  );

  return (
    <div className="container-x py-12">
      <div className="text-center">
        <p className="eyebrow">VELORA</p>
        <h1 className="mt-2 text-5xl">{category || (gender ? `For ${gender === 'Men' ? 'Him' : 'Her'}` : 'All Jewellery')}</h1>
      </div>

      <div className="mt-10 flex flex-col gap-4 border-y border-beige py-4 md:flex-row md:items-center md:justify-between">
        <form onSubmit={(e) => { e.preventDefault(); setParam('search', searchText.trim()); }} className="flex flex-1 items-center gap-3 md:max-w-sm">
          <Search size={18} className="text-charcoal/50" />
          <input value={searchText} onChange={(e) => setSearchText(e.target.value)} placeholder="Search jewellery" aria-label="Search products"
            className="w-full bg-transparent py-1.5 text-sm outline-none placeholder:text-charcoal/40" />
          {searchText && <button type="button" onClick={() => { setSearchText(''); setParam('search', ''); }} aria-label="Clear search"><X size={16} /></button>}
        </form>
        <div className="flex items-center justify-between gap-4 md:justify-end">
          <button onClick={() => setFiltersOpen(true)} className="flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] lg:hidden">
            <SlidersHorizontal size={16} /> Filters
          </button>
          <label className="flex items-center gap-3 text-[11px] uppercase tracking-[0.2em]">
            Sort
            <select value={sort} onChange={(e) => setParam('sort', e.target.value === 'featured' ? '' : e.target.value)}
              className="border border-charcoal/25 bg-transparent px-3 py-2 text-xs normal-case tracking-normal outline-none focus:border-gold">
              {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </label>
        </div>
      </div>

      <div className="mt-8 grid gap-10 lg:grid-cols-[220px_1fr]">
        <aside className="hidden lg:block">{filters}</aside>

        {filtersOpen && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div className="absolute inset-0 bg-charcoal/50" onClick={() => setFiltersOpen(false)} />
            <div className="absolute right-0 top-0 h-full w-4/5 max-w-sm overflow-y-auto bg-ivory p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl">Filters</h2>
                <button onClick={() => setFiltersOpen(false)} aria-label="Close filters"><X size={22} /></button>
              </div>
              {filters}
              <button onClick={() => setFiltersOpen(false)} className="btn-dark mt-6 w-full">Show {filtered.length} results</button>
            </div>
          </div>
        )}

        <section>
          <div className="mb-6 flex items-center justify-between text-sm text-charcoal/60">
            <span>{loading ? 'Loading…' : `${filtered.length} piece${filtered.length === 1 ? '' : 's'}`}</span>
            {hasFilters && <button onClick={clearAll} className="underline underline-offset-4 hover:text-gold-dark">Clear all filters</button>}
          </div>
          {loading ? <ProductGridSkeleton count={6} />
            : error ? <ErrorState message={error} onRetry={reload} />
            : filtered.length === 0 ? (
              <EmptyState title="No pieces found" message={hasFilters ? 'Try adjusting or clearing your filters.' : 'No products are available yet.'}
                actionLabel={hasFilters ? 'Clear filters' : undefined} onAction={hasFilters ? clearAll : undefined} />
            ) : (
              <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
                {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
              </div>
            )}
        </section>
      </div>
    </div>
  );
}
