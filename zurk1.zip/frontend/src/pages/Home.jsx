import { Link } from 'react-router-dom';
import { ArrowRight, Gem, ShieldCheck, Truck } from 'lucide-react';
import { fetchProducts } from '../api/products';
import { useFetch } from '../utils/useFetch';
import ProductCard from '../components/ProductCard';
import Newsletter from '../components/Newsletter';
import { ErrorState, EmptyState, ProductGridSkeleton } from '../components/StateViews';

const IMG = (id, w = 1400) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;

const collections = [
  { title: 'Rings', to: '/shop?category=Rings', img: IMG('photo-1605100804763-247f67b3557e', 900) },
  { title: 'Necklaces', to: '/shop?category=Necklaces', img: IMG('photo-1599643478518-a784e5dc4c8f', 900) },
  { title: 'Earrings', to: '/shop?category=Earrings', img: IMG('photo-1535632066927-ab7c9ab60908', 900) },
  { title: 'For Him', to: '/shop?gender=Men', img: IMG('photo-1611591437281-460bfbe1220a', 900) },
];

function SectionHead({ eyebrow, title, to, cta = 'View all' }) {
  return (
    <div className="mb-10 flex items-end justify-between">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2 className="mt-2 text-4xl md:text-5xl">{title}</h2>
      </div>
      {to && (
        <Link to={to} className="hidden items-center gap-2 text-[11px] uppercase tracking-[0.2em] hover:text-gold-dark sm:flex">
          {cta} <ArrowRight size={14} />
        </Link>
      )}
    </div>
  );
}

function ProductRow({ products, loading, error, reload, emptyMsg }) {
  if (loading) return <ProductGridSkeleton count={4} />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!products.length) return <EmptyState title="Nothing here yet" message={emptyMsg} />;
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
      {products.map((p) => <ProductCard key={p.id} product={p} />)}
    </div>
  );
}

export default function Home() {
  const { data, loading, error, reload } = useFetch((signal) => fetchProducts({}, signal), []);
  const all = data || [];
  const bestsellers = all.filter((p) => p.bestseller).slice(0, 4);
  const newest = (all.some((p) => p.isNew) ? all.filter((p) => p.isNew) : all).slice(0, 4);

  return (
    <>
      {/* Hero */}
      <section className="relative">
        <div className="grid min-h-[78vh] md:grid-cols-2">
          <div className="flex items-center bg-beige/60 px-5 py-20 sm:px-12 lg:px-20">
            <div className="max-w-lg animate-fade-up">
              <p className="eyebrow">New Season · 2026</p>
              <h1 className="mt-5 text-5xl leading-[1.05] md:text-7xl">Gold, <em className="font-normal text-gold-dark">quietly</em> extraordinary.</h1>
              <p className="mt-6 max-w-md text-[15px] leading-relaxed text-charcoal/70">
                Gold and diamond jewellery for men and women. Considered design, honest materials, made to be worn daily.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <Link to="/shop" className="btn-dark">Shop the collection</Link>
                <a href="#story" className="btn-outline">Our story</a>
              </div>
            </div>
          </div>
          <div className="relative min-h-[360px]">
            <img src={IMG('photo-1515562141207-7a88fb7ce338', 1400)} alt="Gold necklace with diamond pendant" className="absolute inset-0 h-full w-full object-cover" />
          </div>
        </div>
      </section>

      {/* Brand intro */}
      <section className="container-x py-24 text-center">
        <p className="eyebrow">The House of VELORA</p>
        <h2 className="mx-auto mt-4 max-w-3xl text-3xl leading-snug md:text-5xl">
          Jewellery that needs no announcement. Only the quiet confidence of fine craft.
        </h2>
        <div className="mx-auto mt-14 grid max-w-4xl gap-10 sm:grid-cols-3">
          {[
            { Icon: Gem, t: 'Certified diamonds', d: 'Every stone graded and ethically sourced.' },
            { Icon: ShieldCheck, t: 'Hallmarked gold', d: '18K and 22K gold, BIS hallmarked.' },
            { Icon: Truck, t: 'Insured delivery', d: 'Fully insured, tracked shipping.' },
          ].map(({ Icon, t, d }) => (
            <div key={t}>
              <Icon className="mx-auto text-gold-dark" size={28} strokeWidth={1.2} />
              <h3 className="mt-4 text-xl">{t}</h3>
              <p className="mt-1 text-sm text-charcoal/65">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured collections */}
      <section className="container-x pb-24">
        <SectionHead eyebrow="Featured" title="Collections" to="/shop" cta="Shop all" />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {collections.map((c) => (
            <Link key={c.title} to={c.to} className="group relative block aspect-[3/4] overflow-hidden bg-beige">
              <img src={c.img} alt={c.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 via-transparent to-transparent" />
              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between p-5 text-ivory">
                <span className="font-serif text-2xl">{c.title}</span>
                <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Bestsellers */}
      <section className="container-x pb-24">
        <SectionHead eyebrow="Most loved" title="Bestsellers" to="/shop" />
        <ProductRow products={bestsellers} loading={loading} error={error} reload={reload} emptyMsg="Bestselling pieces will appear here." />
      </section>

      {/* Story */}
      <section id="story" className="bg-beige/60">
        <div className="container-x grid items-center gap-12 py-24 md:grid-cols-2">
          <img src={IMG('photo-1573408301185-9146fe634ad0', 1100)} alt="Jeweller crafting gold" loading="lazy" className="aspect-[4/5] w-full object-cover" />
          <div className="max-w-md">
            <p className="eyebrow">Our story</p>
            <h2 className="mt-4 text-4xl md:text-5xl">Made slowly. Worn always.</h2>
            <p className="mt-6 text-[15px] leading-relaxed text-charcoal/75">
              VELORA began with a simple belief: luxury is not volume, it is restraint. Each piece is drawn by hand, cast in recycled gold, and finished by artisans who have spent decades at the bench.
            </p>
            <p className="mt-4 text-[15px] leading-relaxed text-charcoal/75">
              We design for men and women who prefer pieces that last a lifetime, and quietly become part of their story.
            </p>
            <Link to="/shop" className="btn-dark mt-8">Discover the pieces</Link>
          </div>
        </div>
      </section>

      {/* New arrivals */}
      <section className="container-x py-24">
        <SectionHead eyebrow="Just in" title="New Arrivals" to="/shop?sort=newest" />
        <ProductRow products={newest} loading={loading} error={error} reload={reload} emptyMsg="New arrivals will appear here." />
      </section>

      <Newsletter />
    </>
  );
}
