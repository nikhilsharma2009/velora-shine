import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CheckCircle2, Lock } from 'lucide-react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';
import { formatPrice, FALLBACK_IMG } from '../utils/format';
import { loadRazorpay } from '../utils/razorpay';
import { EmptyState, Spinner } from '../components/StateViews';

const RAZORPAY_KEY = import.meta.env.VITE_RAZORPAY_KEY_ID;

const empty = { fullName: '', phone: '', address: '', city: '', state: '', pincode: '' };

function validate(f) {
  const e = {};
  if (f.fullName.trim().length < 2) e.fullName = 'Enter the recipient name';
  if (!/^[6-9]\d{9}$/.test(f.phone.trim())) e.phone = 'Enter a valid 10-digit mobile number';
  if (f.address.trim().length < 6) e.address = 'Enter the full address';
  if (!f.city.trim()) e.city = 'Enter the city';
  if (!f.state.trim()) e.state = 'Enter the state';
  if (!/^\d{6}$/.test(f.pincode.trim())) e.pincode = 'Enter a valid 6-digit PIN code';
  return e;
}

export default function Checkout() {
  const { user } = useAuth();
  const cart = useCart();
  const toast = useToast();
  const navigate = useNavigate();

  const [form, setForm] = useState({ ...empty, fullName: user?.name || '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [placed, setPlaced] = useState(null);

  if (placed) {
    return (
      <div className="container-x py-24 text-center">
        <CheckCircle2 className="mx-auto text-gold-dark" size={48} strokeWidth={1.2} />
        <h1 className="mt-5 text-5xl">Thank you</h1>
        <p className="mt-3 text-charcoal/70">Your payment was verified and your order is confirmed.</p>
        {placed.id && <p className="mt-1 text-sm text-charcoal/60">Order reference: {placed.id}</p>}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to="/account?tab=orders" className="btn-dark">View my orders</Link>
          <Link to="/shop" className="btn-outline">Continue shopping</Link>
        </div>
      </div>
    );
  }

  if (cart.loading) return <Spinner label="Preparing checkout" />;
  if (cart.items.length === 0) {
    return <EmptyState title="Nothing to check out" message="Add a piece to your cart first." actionLabel="Shop jewellery" actionTo="/shop" />;
  }

  const set = (k) => (e) => { setForm({ ...form, [k]: e.target.value }); if (errors[k]) setErrors({ ...errors, [k]: undefined }); };

  const field = (k, label, { className = '', ...props } = {}) => (
    <div className={className}>
      <label className="label" htmlFor={k}>{label}</label>
      <input id={k} className={`input ${errors[k] ? '!border-red-600' : ''}`} value={form[k]} onChange={set(k)} {...props} />
      {errors[k] && <p className="mt-1 text-xs text-red-700">{errors[k]}</p>}
    </div>
  );

  const pay = async (e) => {
    e.preventDefault();
    setMessage('');
    const errs = validate(form);
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    try {
      // 1. Backend creates our order + the Razorpay order. Amount is decided server-side.
      const created = await api.createOrder({
        items: cart.items.map((i) => ({ productId: i.productId, quantity: i.quantity, size: i.size })),
        shippingAddress: { ...form },
      });
      const order = created.order || created;
      const orderId = order._id || order.id || created.orderId;
      const razorpayOrderId = created.razorpayOrderId || created.razorpay_order_id || order.razorpayOrderId;
      const amount = created.amount ?? order.amount;
      const currency = created.currency || 'INR';
      const key = created.key || created.razorpayKeyId || RAZORPAY_KEY;

      if (!razorpayOrderId || !amount) throw new Error('The server did not return a valid payment order. Please try again.');
      if (!key) throw new Error('Payments are not configured (missing Razorpay key id).');

      // 2. Open Razorpay checkout
      const ok = await loadRazorpay();
      if (!ok) throw new Error('Could not load the payment window. Check your connection and try again.');

      const rzp = new window.Razorpay({
        key,
        amount,
        currency,
        name: 'VELORA',
        description: 'Luxury jewellery order',
        order_id: razorpayOrderId,
        prefill: { name: form.fullName, email: user?.email, contact: form.phone },
        theme: { color: '#C6A66B' },
        modal: {
          ondismiss: () => { setBusy(false); setMessage('Payment was cancelled. Your cart is still saved.'); },
        },
        handler: async (response) => {
          // 3. Backend verifies the signature. We only show success if it confirms.
          try {
            await api.verifyPayment({
              orderId,
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });
            cart.clearLocal();
            cart.reload();
            setPlaced({ id: orderId });
            toast.success('Payment confirmed');
          } catch (err) {
            setMessage(`We could not verify your payment: ${err.message} If money was deducted, please contact support with payment ID ${response.razorpay_payment_id}.`);
          } finally {
            setBusy(false);
          }
        },
      });
      rzp.on('payment.failed', (resp) => {
        setBusy(false);
        setMessage(resp?.error?.description || 'Payment failed. Please try again.');
      });
      rzp.open();
    } catch (err) {
      setMessage(err.message);
      setBusy(false);
    }
  };

  return (
    <div className="container-x py-12">
      <h1 className="text-center text-5xl">Checkout</h1>
      <form onSubmit={pay} noValidate className="mt-12 grid gap-12 lg:grid-cols-[1fr_400px]">
        <section>
          <h2 className="text-2xl">Shipping details</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            {field('fullName', 'Full name', { autoComplete: 'name', className: 'sm:col-span-2' })}
            {field('phone', 'Mobile number', { autoComplete: 'tel', inputMode: 'numeric', maxLength: 10 })}
            {field('pincode', 'PIN code', { autoComplete: 'postal-code', inputMode: 'numeric', maxLength: 6 })}
            {field('address', 'Address', { autoComplete: 'street-address', className: 'sm:col-span-2' })}
            {field('city', 'City', { autoComplete: 'address-level2' })}
            {field('state', 'State', { autoComplete: 'address-level1' })}
          </div>
        </section>

        <aside className="h-fit border border-beige bg-white/40 p-7">
          <h2 className="text-2xl">Order summary</h2>
          <ul className="mt-6 divide-y divide-beige">
            {cart.items.map((i) => (
              <li key={i.id} className="flex gap-4 py-4">
                <img src={i.product.images[0] || FALLBACK_IMG} alt="" className="h-20 w-16 object-cover" onError={(e) => { e.currentTarget.src = FALLBACK_IMG; }} />
                <div className="flex-1 text-sm">
                  <p className="font-serif text-base leading-snug">{i.product.name}</p>
                  <p className="mt-0.5 text-xs text-charcoal/55">Qty {i.quantity}{i.size ? ` · Size ${i.size}` : ''}</p>
                </div>
                <p className="text-sm">{formatPrice(i.product.price * i.quantity)}</p>
              </li>
            ))}
          </ul>
          <div className="mt-4 space-y-2 border-t border-beige pt-4 text-sm">
            <div className="flex justify-between"><span className="text-charcoal/70">Subtotal</span><span>{formatPrice(cart.subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-charcoal/70">Shipping</span><span>Free</span></div>
            <div className="flex justify-between pt-2 font-serif text-xl"><span>Total</span><span>{formatPrice(cart.subtotal)}</span></div>
          </div>
          {message && <p role="alert" className="mt-5 border-l-2 border-red-600 bg-red-50 px-3 py-2 text-sm text-red-800">{message}</p>}
          <button disabled={busy} className="btn-dark mt-6 w-full"><Lock size={14} /> {busy ? 'Processing…' : 'Pay securely with Razorpay'}</button>
          <p className="mt-3 text-center text-xs text-charcoal/55">Payments are processed and verified by Razorpay and our server.</p>
        </aside>
      </form>
    </div>
  );
}
