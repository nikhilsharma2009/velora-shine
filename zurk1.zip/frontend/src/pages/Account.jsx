import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Heart, LogOut, Package, User as UserIcon, Trash2, LayoutDashboard } from 'lucide-react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';
import { useFetch } from '../utils/useFetch';
import { formatDate, formatPrice, FALLBACK_IMG } from '../utils/format';
import { EmptyState, ErrorState, Spinner } from '../components/StateViews';
import ProductCard from '../components/ProductCard';

const STATUS_STYLES = {
  pending: 'bg-beige text-charcoal',
  paid: 'bg-gold/30 text-charcoal',
  processing: 'bg-gold/30 text-charcoal',
  shipped: 'bg-charcoal/10 text-charcoal',
  delivered: 'bg-charcoal text-ivory',
  cancelled: 'bg-red-100 text-red-800',
  failed: 'bg-red-100 text-red-800',
};

export function StatusBadge({ status }) {
  const s = String(status || 'pending').toLowerCase();
  return <span className={`inline-block px-2.5 py-1 text-[10px] uppercase tracking-[0.15em] ${STATUS_STYLES[s] || STATUS_STYLES.pending}`}>{s}</span>;
}

function Orders() {
  const { data, loading, error, reload } = useFetch(() => api.getMyOrders(), []);
  if (loading) return <Spinner label="Loading orders" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!data.length) return <EmptyState title="No orders yet" message="Your orders will appear here once you place one." actionLabel="Start shopping" actionTo="/shop" />;

  return (
    <ul className="space-y-6">
      {data.map((o) => {
        const id = o._id || o.id;
        const items = o.items || o.orderItems || [];
        const total = o.total ?? o.totalAmount ?? o.amount;
        return (
          <li key={id} className="border border-beige bg-white/40 p-6">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-beige pb-4">
              <div>
                <p className="text-xs uppercase tracking-[0.18em] text-charcoal/55">Order #{String(id).slice(-8).toUpperCase()}</p>
                <p className="mt-1 text-sm text-charcoal/70">{formatDate(o.createdAt)}</p>
              </div>
              <div className="flex items-center gap-4">
                <StatusBadge status={o.status || o.orderStatus} />
                {total != null && <span className="font-serif text-lg">{formatPrice(total)}</span>}
              </div>
            </div>
            <ul className="mt-4 space-y-3">
              {items.map((it, idx) => {
                const p = it.product && typeof it.product === 'object' ? it.product : {};
                const name = it.name || p.name || 'Item';
                const img = it.image || it.images?.[0] || p.images?.[0] || p.image || FALLBACK_IMG;
                return (
                  <li key={idx} className="flex items-center gap-4 text-sm">
                    <img src={img} alt="" className="h-16 w-12 object-cover" onError={(e) => { e.currentTarget.src = FALLBACK_IMG; }} />
                    <div className="flex-1">
                      <p className="font-serif text-base">{name}</p>
                      <p className="text-xs text-charcoal/55">Qty {it.quantity || it.qty || 1}{it.size ? ` · Size ${it.size}` : ''}</p>
                    </div>
                    {(it.price ?? p.price) != null && <span>{formatPrice(it.price ?? p.price)}</span>}
                  </li>
                );
              })}
            </ul>
          </li>
        );
      })}
    </ul>
  );
}

function Profile() {
  const { user } = useAuth();
  return (
    <div className="max-w-lg border border-beige bg-white/40 p-8">
      <div className="mb-6 grid h-16 w-16 place-items-center rounded-full bg-gold text-2xl text-charcoal font-serif">
        {(user?.name || '?').charAt(0).toUpperCase()}
      </div>
      <dl className="space-y-5 text-sm">
        <div><dt className="label">Name</dt><dd className="text-base">{user?.name || '—'}</dd></div>
        <div><dt className="label">Email</dt><dd className="text-base">{user?.email || '—'}</dd></div>
        <div><dt className="label">Account type</dt><dd className="text-base capitalize">{user?.role || 'customer'}</dd></div>
        {user?.createdAt && <div><dt className="label">Member since</dt><dd className="text-base">{formatDate(user.createdAt)}</dd></div>}
      </dl>
    </div>
  );
}

function Wishlist() {
  const wishlist = useWishlist();
  const cart = useCart();
  const toast = useToast();

  if (!wishlist.items.length) {
    return <EmptyState title="Your wishlist is empty" message="Tap the heart on any piece to save it here." actionLabel="Browse jewellery" actionTo="/shop" />;
  }
  const moveToCart = async (p) => {
    if (p.sizes?.length) { toast.error('Please choose a size on the product page.'); return; }
    try { await cart.addItem(p, { quantity: 1 }); wishlist.remove(p.id); toast.success('Moved to cart'); }
    catch (e) { toast.error(e.message); }
  };
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
      {wishlist.items.map((p) => (
        <div key={p.id}>
          <ProductCard product={p} />
          <div className="mt-3 flex justify-center gap-4 text-[11px] uppercase tracking-[0.15em]">
            {p.sizes?.length
              ? <Link to={`/product/${p.id}`} className="hover:text-gold-dark">Choose size</Link>
              : <button onClick={() => moveToCart(p)} className="hover:text-gold-dark">Move to cart</button>}
            <button onClick={() => wishlist.remove(p.id)} className="flex items-center gap-1 text-charcoal/55 hover:text-red-700"><Trash2 size={12} /> Remove</button>
          </div>
        </div>
      ))}
    </div>
  );
}

const TABS = [
  { id: 'profile', label: 'Profile', Icon: UserIcon },
  { id: 'orders', label: 'Orders', Icon: Package },
  { id: 'wishlist', label: 'Wishlist', Icon: Heart },
];

export default function Account() {
  const [params, setParams] = useSearchParams();
  const tab = TABS.some((t) => t.id === params.get('tab')) ? params.get('tab') : 'profile';
  const { user, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { document.title = 'My Account | VELORA'; }, []);

  return (
    <div className="container-x py-12">
      <p className="eyebrow">My account</p>
      <h1 className="mt-2 text-5xl">Hello, {user?.name?.split(' ')[0] || 'there'}</h1>

      <div className="mt-10 grid gap-10 md:grid-cols-[220px_1fr]">
        <nav className="flex gap-2 overflow-x-auto md:flex-col md:gap-1">
          {TABS.map(({ id, label, Icon }) => (
            <button key={id} onClick={() => setParams({ tab: id })}
              className={`flex items-center gap-3 whitespace-nowrap border-l-2 px-4 py-3 text-sm transition ${tab === id ? 'border-gold bg-beige/60' : 'border-transparent hover:bg-beige/40'}`}>
              <Icon size={17} /> {label}
            </button>
          ))}
          {isAdmin && (
            <Link to="/admin" className="flex items-center gap-3 whitespace-nowrap border-l-2 border-transparent px-4 py-3 text-sm hover:bg-beige/40"><LayoutDashboard size={17} /> Admin</Link>
          )}
          <button onClick={() => { logout(); navigate('/'); }} className="flex items-center gap-3 whitespace-nowrap border-l-2 border-transparent px-4 py-3 text-sm text-charcoal/60 hover:text-red-700">
            <LogOut size={17} /> Sign out
          </button>
        </nav>
        <section>
          {tab === 'profile' && <Profile />}
          {tab === 'orders' && <Orders />}
          {tab === 'wishlist' && <Wishlist />}
        </section>
      </div>
    </div>
  );
}
