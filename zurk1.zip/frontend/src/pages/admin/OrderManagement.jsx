import { useState } from 'react';
import { api } from '../../api/client';
import { useFetch } from '../../utils/useFetch';
import { useToast } from '../../context/ToastContext';
import { formatDate, formatPrice } from '../../utils/format';
import { EmptyState, ErrorState, Spinner } from '../../components/StateViews';
import { StatusBadge } from '../Account';

const STATUSES = ['pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled'];

export default function OrderManagement() {
  const { data, loading, error, reload } = useFetch(() => api.adminGetOrders(), []);
  const toast = useToast();
  const [busyId, setBusyId] = useState(null);
  const [filter, setFilter] = useState('all');

  const changeStatus = async (id, status) => {
    setBusyId(id);
    try { await api.adminUpdateOrderStatus(id, status); toast.success('Order status updated'); reload(); }
    catch (e) { toast.error(e.message); }
    finally { setBusyId(null); }
  };

  if (loading) return <Spinner label="Loading orders" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!data.length) return <EmptyState title="No orders yet" message="Customer orders will appear here." />;

  const list = filter === 'all' ? data : data.filter((o) => String(o.status || o.orderStatus || 'pending').toLowerCase() === filter);

  return (
    <div>
      <div className="mb-6 flex flex-wrap gap-2">
        {['all', ...STATUSES].map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-4 py-2 text-[11px] uppercase tracking-[0.15em] transition ${filter === s ? 'bg-charcoal text-ivory' : 'border border-charcoal/20 hover:border-gold'}`}>{s}</button>
        ))}
      </div>
      {list.length === 0 ? <EmptyState title="No matching orders" /> : (
        <div className="overflow-x-auto border border-beige">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="bg-beige/60 text-[11px] uppercase tracking-[0.15em] text-charcoal/70">
              <tr><th className="p-4">Order</th><th className="p-4">Customer</th><th className="p-4">Date</th><th className="p-4">Total</th><th className="p-4">Status</th><th className="p-4">Update</th></tr>
            </thead>
            <tbody className="divide-y divide-beige">
              {list.map((o) => {
                const id = o._id || o.id;
                const status = String(o.status || o.orderStatus || 'pending').toLowerCase();
                const customer = o.user?.name || o.shippingAddress?.fullName || o.user?.email || '—';
                return (
                  <tr key={id} className={busyId === id ? 'opacity-40' : ''}>
                    <td className="p-4 font-mono text-xs">#{String(id).slice(-8).toUpperCase()}</td>
                    <td className="p-4">{customer}</td>
                    <td className="p-4">{formatDate(o.createdAt)}</td>
                    <td className="p-4">{formatPrice(o.total ?? o.totalAmount ?? o.amount)}</td>
                    <td className="p-4"><StatusBadge status={status} /></td>
                    <td className="p-4">
                      <select disabled={busyId === id} value={status} onChange={(e) => changeStatus(id, e.target.value)} className="border border-charcoal/25 bg-transparent px-2 py-1.5 text-xs outline-none focus:border-gold">
                        {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
