import { useState } from 'react';
import { Boxes, Package, ShoppingBag } from 'lucide-react';
import ProductManagement from './ProductManagement';
import OrderManagement from './OrderManagement';
import InventoryManagement from './InventoryManagement';

const TABS = [
  { id: 'products', label: 'Products', Icon: ShoppingBag, View: ProductManagement },
  { id: 'orders', label: 'Orders', Icon: Package, View: OrderManagement },
  { id: 'inventory', label: 'Inventory', Icon: Boxes, View: InventoryManagement },
];

export default function Admin() {
  const [tab, setTab] = useState('products');
  const Active = TABS.find((t) => t.id === tab).View;

  return (
    <div className="container-x py-12">
      <p className="eyebrow">Administration</p>
      <h1 className="mt-2 text-5xl">Dashboard</h1>
      <div className="mt-8 flex gap-1 overflow-x-auto border-b border-beige">
        {TABS.map(({ id, label, Icon }) => (
          <button key={id} onClick={() => setTab(id)}
            className={`flex items-center gap-2 whitespace-nowrap border-b-2 px-5 py-3 text-sm transition ${tab === id ? 'border-gold text-charcoal' : 'border-transparent text-charcoal/60 hover:text-charcoal'}`}>
            <Icon size={16} /> {label}
          </button>
        ))}
      </div>
      <div className="mt-8"><Active /></div>
    </div>
  );
}
