import { useState } from 'react';
import { Pencil, Plus, Trash2, X } from 'lucide-react';
import { api } from '../../api/client';
import { fetchProducts } from '../../api/products';
import { useFetch } from '../../utils/useFetch';
import { useToast } from '../../context/ToastContext';
import { formatPrice, FALLBACK_IMG } from '../../utils/format';
import { EmptyState, ErrorState, Spinner } from '../../components/StateViews';

const CATEGORIES = ['Rings', 'Necklaces', 'Earrings', 'Bracelets'];
const blank = { name: '', price: '', category: 'Rings', gender: 'Women', material: '', description: '', image: '', sizes: '', stock: '' };

function ProductForm({ initial, onClose, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState(initial ? {
    name: initial.name, price: String(initial.price), category: initial.category, gender: initial.gender,
    material: initial.material, description: initial.description, image: initial.images[0] || '',
    sizes: initial.sizes.join(', '), stock: initial.stock ?? '',
  } : blank);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!f.name.trim()) return setError('Name is required.');
    if (!(Number(f.price) > 0)) return setError('Enter a valid price.');
    const payload = {
      name: f.name.trim(), price: Number(f.price), category: f.category, gender: f.gender,
      material: f.material.trim(), description: f.description.trim(),
      images: f.image.trim() ? [f.image.trim()] : [],
      sizes: f.sizes.split(',').map((s) => s.trim()).filter(Boolean),
      stock: f.stock === '' ? 0 : Number(f.stock),
    };
    setBusy(true);
    try {
      if (initial) await api.adminUpdateProduct(initial.id, payload); else await api.adminCreateProduct(payload);
      toast.success(initial ? 'Product updated' : 'Product created');
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto p-4">
      <div className="fixed inset-0 bg-charcoal/50" onClick={onClose} />
      <form onSubmit={submit} className="relative my-8 w-full max-w-2xl bg-ivory p-7 shadow-2xl">
        <button type="button" onClick={onClose} className="absolute right-5 top-5" aria-label="Close"><X size={20} /></button>
        <h2 className="text-3xl">{initial ? 'Edit product' : 'New product'}</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2"><label className="label">Name</label><input className="input" value={f.name} onChange={set('name')} /></div>
          <div><label className="label">Price (₹)</label><input type="number" min="0" className="input" value={f.price} onChange={set('price')} /></div>
          <div><label className="label">Stock</label><input type="number" min="0" className="input" value={f.stock} onChange={set('stock')} /></div>
          <div><label className="label">Category</label>
            <select className="input" value={f.category} onChange={set('category')}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
          <div><label className="label">For</label>
            <select className="input" value={f.gender} onChange={set('gender')}>{['Women', 'Men', 'Unisex'].map((c) => <option key={c}>{c}</option>)}</select></div>
          <div className="sm:col-span-2"><label className="label">Material</label><input className="input" value={f.material} onChange={set('material')} placeholder="18K Gold, Diamond" /></div>
          <div className="sm:col-span-2"><label className="label">Image URL</label><input className="input" value={f.image} onChange={set('image')} placeholder="https://…" /></div>
          <div className="sm:col-span-2"><label className="label">Sizes (comma separated)</label><input className="input" value={f.sizes} onChange={set('sizes')} placeholder="6, 7, 8" /></div>
          <div className="sm:col-span-2"><label className="label">Description</label><textarea rows={3} className="input" value={f.description} onChange={set('description')} /></div>
        </div>
        {error && <p role="alert" className="mt-4 text-sm text-red-700">{error}</p>}
        <div className="mt-6 flex justify-end gap-3">
          <button type="button" onClick={onClose} className="btn-outline">Cancel</button>
          <button disabled={busy} className="btn-dark">{busy ? 'Saving…' : 'Save product'}</button>
        </div>
      </form>
    </div>
  );
}

export default function ProductManagement() {
  const { data, loading, error, reload } = useFetch((signal) => fetchProducts({}, signal), []);
  const toast = useToast();
  const [editing, setEditing] = useState(null); // null | 'new' | product
  const [deleting, setDeleting] = useState(null);

  const remove = async (p) => {
    if (!window.confirm(`Delete "${p.name}"? This cannot be undone.`)) return;
    setDeleting(p.id);
    try { await api.adminDeleteProduct(p.id); toast.success('Product deleted'); reload(); }
    catch (e) { toast.error(e.message); }
    finally { setDeleting(null); }
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <p className="text-sm text-charcoal/60">{data ? `${data.length} products` : ''}</p>
        <button onClick={() => setEditing('new')} className="btn-dark"><Plus size={14} /> Add product</button>
      </div>

      {loading ? <Spinner label="Loading products" />
        : error ? <ErrorState message={error} onRetry={reload} />
        : !data.length ? <EmptyState title="No products yet" message="Add your first piece to get started." actionLabel="Add product" onAction={() => setEditing('new')} />
        : (
          <div className="overflow-x-auto border border-beige">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="bg-beige/60 text-[11px] uppercase tracking-[0.15em] text-charcoal/70">
                <tr><th className="p-4">Product</th><th className="p-4">Category</th><th className="p-4">Price</th><th className="p-4">Stock</th><th className="p-4 text-right">Actions</th></tr>
              </thead>
              <tbody className="divide-y divide-beige">
                {data.map((p) => (
                  <tr key={p.id} className={deleting === p.id ? 'opacity-40' : ''}>
                    <td className="p-4"><div className="flex items-center gap-3">
                      <img src={p.images[0] || FALLBACK_IMG} alt="" className="h-12 w-10 object-cover" onError={(e) => { e.currentTarget.src = FALLBACK_IMG; }} />
                      <span className="font-serif text-base">{p.name}</span></div></td>
                    <td className="p-4">{p.category}</td>
                    <td className="p-4">{formatPrice(p.price)}</td>
                    <td className="p-4">{p.stock ?? '—'}</td>
                    <td className="p-4"><div className="flex justify-end gap-3">
                      <button onClick={() => setEditing(p)} aria-label={`Edit ${p.name}`} className="hover:text-gold-dark"><Pencil size={16} /></button>
                      <button disabled={deleting === p.id} onClick={() => remove(p)} aria-label={`Delete ${p.name}`} className="hover:text-red-700"><Trash2 size={16} /></button>
                    </div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      {editing && (
        <ProductForm initial={editing === 'new' ? null : editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); reload(); }} />
      )}
    </div>
  );
}
