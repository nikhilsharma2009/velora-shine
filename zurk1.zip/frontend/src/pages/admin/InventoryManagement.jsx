import { useEffect, useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { api } from '../../api/client';
import { fetchProducts } from '../../api/products';
import { useFetch } from '../../utils/useFetch';
import { useToast } from '../../context/ToastContext';
import { EmptyState, ErrorState, Spinner } from '../../components/StateViews';

const LOW = 5;

function Row({ product, onSaved }) {
  const toast = useToast();
  const [value, setValue] = useState(String(product.stock ?? 0));
  const [busy, setBusy] = useState(false);
  useEffect(() => setValue(String(product.stock ?? 0)), [product.stock]);

  const dirty = Number(value) !== (product.stock ?? 0);
  const save = async () => {
    const n = Number(value);
    if (!Number.isInteger(n) || n < 0) { toast.error('Stock must be a whole number, 0 or more.'); return; }
    setBusy(true);
    try { await api.adminUpdateProduct(product.id, { stock: n }); toast.success('Stock updated'); onSaved(); }
    catch (e) { toast.error(e.message); }
    finally { setBusy(false); }
  };

  const stock = product.stock ?? 0;
  const state = stock === 0 ? { t: 'Out of stock', c: 'text-red-700' } : stock <= LOW ? { t: 'Low stock', c: 'text-gold-dark' } : { t: 'In stock', c: 'text-charcoal/60' };

  return (
    <tr>
      <td className="p-4 font-serif text-base">{product.name}</td>
      <td className="p-4">{product.category}</td>
      <td className={`p-4 text-xs uppercase tracking-[0.12em] ${state.c}`}>{state.t}</td>
      <td className="p-4">
        <div className="flex items-center gap-2">
          <input type="number" min="0" value={value} onChange={(e) => setValue(e.target.value)} className="input !w-24 !py-1.5" aria-label={`Stock for ${product.name}`} />
          <button disabled={!dirty || busy} onClick={save} className="btn-dark !px-4 !py-2">{busy ? 'Saving…' : 'Save'}</button>
        </div>
      </td>
    </tr>
  );
}

export default function InventoryManagement() {
  const { data, loading, error, reload } = useFetch((signal) => fetchProducts({}, signal), []);
  if (loading) return <Spinner label="Loading inventory" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!data.length) return <EmptyState title="No inventory" message="Add products to manage their stock." />;

  const low = data.filter((p) => (p.stock ?? 0) <= LOW);

  return (
    <div>
      {low.length > 0 && (
        <div className="mb-6 flex items-start gap-3 border border-gold/50 bg-gold/10 p-4 text-sm">
          <AlertTriangle size={18} className="mt-0.5 text-gold-dark" />
          <p>{low.length} product{low.length > 1 ? 's are' : ' is'} low or out of stock: {low.map((p) => p.name).join(', ')}.</p>
        </div>
      )}
      <div className="overflow-x-auto border border-beige">
        <table className="w-full min-w-[600px] text-left text-sm">
          <thead className="bg-beige/60 text-[11px] uppercase tracking-[0.15em] text-charcoal/70">
            <tr><th className="p-4">Product</th><th className="p-4">Category</th><th className="p-4">Status</th><th className="p-4">Stock</th></tr>
          </thead>
          <tbody className="divide-y divide-beige">
            {data.map((p) => <Row key={p.id} product={p} onSaved={reload} />)}
          </tbody>
        </table>
      </div>
    </div>
  );
}
