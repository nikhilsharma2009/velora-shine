// Centralized API service layer for VELORA.
// All network access goes through this file. Pages and contexts never call fetch directly.

export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api').replace(/\/$/, '');
export const USE_MOCK_FALLBACK = import.meta.env.VITE_USE_MOCK_FALLBACK === 'true';

const TOKEN_KEY = 'velora_token';

export const tokenStore = {
  get: () => {
    try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
  },
  set: (t) => {
    try { localStorage.setItem(TOKEN_KEY, t); } catch { /* ignore */ }
  },
  clear: () => {
    try { localStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
  },
};

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

async function request(path, { method = 'GET', body, auth = true, signal } = {}) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const token = tokenStore.get();
  if (auth && token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(`${API_BASE_URL}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal,
    });
  } catch (err) {
    if (err.name === 'AbortError') throw err;
    throw new ApiError('Unable to reach the server. Please check your connection and try again.', 0);
  }

  let data = null;
  const text = await res.text();
  if (text) {
    try { data = JSON.parse(text); } catch { data = text; }
  }

  if (!res.ok) {
    const msg = (data && typeof data === 'object' && (data.message || data.error)) || `Request failed (${res.status})`;
    if (res.status === 401) tokenStore.clear();
    throw new ApiError(msg, res.status, data);
  }
  return data;
}

// Backends commonly wrap payloads ({ products: [...] }, { data: [...] }). Normalize here.
const unwrap = (data, keys) => {
  if (data == null) return data;
  for (const k of keys) if (data[k] !== undefined) return data[k];
  return data;
};

// Normalize a product coming from MongoDB (_id) into a stable shape for the UI.
export function normalizeProduct(p) {
  if (!p) return p;
  const images = Array.isArray(p.images) && p.images.length ? p.images : p.image ? [p.image] : [];
  return {
    id: p._id || p.id,
    name: p.name,
    price: Number(p.price) || 0,
    description: p.description || '',
    category: p.category || 'Other',
    gender: p.gender || 'Unisex',
    material: p.material || '',
    images,
    sizes: Array.isArray(p.sizes) ? p.sizes : [],
    stock: p.stock ?? p.countInStock ?? null,
    bestseller: Boolean(p.bestseller ?? p.isBestseller),
    isNew: Boolean(p.isNew ?? p.newArrival),
    createdAt: p.createdAt,
  };
}

function normalizeCartItem(i) {
  const product = normalizeProduct(i.product && typeof i.product === 'object' ? i.product : {
    _id: i.product || i.productId, name: i.name, price: i.price, images: i.images, image: i.image,
  });
  return {
    id: i._id || i.id || `${product.id}-${i.size || ''}`,
    productId: product.id,
    product,
    quantity: i.quantity || i.qty || 1,
    size: i.size || '',
  };
}

export const api = {
  // Products
  async getProducts(params = {}, signal) {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== '' && v != null)
    ).toString();
    const data = await request(`/products${qs ? `?${qs}` : ''}`, { auth: false, signal });
    const list = unwrap(data, ['products', 'data', 'items']);
    return (Array.isArray(list) ? list : []).map(normalizeProduct);
  },
  async getProduct(id, signal) {
    const data = await request(`/products/${encodeURIComponent(id)}`, { auth: false, signal });
    return normalizeProduct(unwrap(data, ['product', 'data']));
  },

  // Auth
  async register(payload) {
    const data = await request('/auth/register', { method: 'POST', body: payload, auth: false });
    return { token: data.token, user: unwrap(data, ['user']) };
  },
  async login(payload) {
    const data = await request('/auth/login', { method: 'POST', body: payload, auth: false });
    return { token: data.token, user: unwrap(data, ['user']) };
  },
  async me() {
    const data = await request('/auth/me');
    return unwrap(data, ['user', 'data']);
  },

  // Cart
  async getCart() {
    const data = await request('/cart');
    const items = unwrap(data, ['items', 'cart', 'data']);
    const arr = Array.isArray(items) ? items : items?.items || [];
    return arr.map(normalizeCartItem);
  },
  async addToCart({ productId, quantity = 1, size }) {
    const data = await request('/cart', { method: 'POST', body: { productId, quantity, size } });
    const items = unwrap(data, ['items', 'cart', 'data']);
    const arr = Array.isArray(items) ? items : items?.items;
    return Array.isArray(arr) ? arr.map(normalizeCartItem) : null;
  },
  async updateCartItem(itemId, { quantity }) {
    const data = await request(`/cart/${encodeURIComponent(itemId)}`, { method: 'PUT', body: { quantity } });
    const items = unwrap(data, ['items', 'cart', 'data']);
    const arr = Array.isArray(items) ? items : items?.items;
    return Array.isArray(arr) ? arr.map(normalizeCartItem) : null;
  },
  async removeCartItem(itemId) {
    const data = await request(`/cart/${encodeURIComponent(itemId)}`, { method: 'DELETE' });
    const items = unwrap(data, ['items', 'cart', 'data']);
    const arr = Array.isArray(items) ? items : items?.items;
    return Array.isArray(arr) ? arr.map(normalizeCartItem) : null;
  },

  // Orders & payments
  // Expected response: { order: {...}, razorpayOrderId, amount, currency } (amount in paise)
  async createOrder(payload) {
    return request('/orders/create', { method: 'POST', body: payload });
  },
  // Backend verifies the Razorpay signature with its secret key. The frontend only forwards the
  // values Razorpay returned. Success is determined solely by the backend response.
  async verifyPayment(payload) {
    return request('/payments/verify', { method: 'POST', body: payload });
  },
  async getMyOrders() {
    const data = await request('/orders/my');
    const list = unwrap(data, ['orders', 'data']);
    return Array.isArray(list) ? list : [];
  },

  // ---- Admin (NOT in the agreed endpoint list yet) ----
  // These follow standard REST conventions and are used only by the admin dashboard.
  // Confirm/adjust the paths with the backend developer. Admin role is enforced server-side.
  async adminCreateProduct(payload) {
    const data = await request('/products', { method: 'POST', body: payload });
    return normalizeProduct(unwrap(data, ['product', 'data']));
  },
  async adminUpdateProduct(id, payload) {
    const data = await request(`/products/${encodeURIComponent(id)}`, { method: 'PUT', body: payload });
    return normalizeProduct(unwrap(data, ['product', 'data']));
  },
  async adminDeleteProduct(id) {
    return request(`/products/${encodeURIComponent(id)}`, { method: 'DELETE' });
  },
  async adminGetOrders() {
    const data = await request('/orders');
    const list = unwrap(data, ['orders', 'data']);
    return Array.isArray(list) ? list : [];
  },
  async adminUpdateOrderStatus(id, status) {
    return request(`/orders/${encodeURIComponent(id)}/status`, { method: 'PUT', body: { status } });
  },
};
