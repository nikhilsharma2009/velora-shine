import { api, ApiError, USE_MOCK_FALLBACK } from './client';
import { mockProducts } from '../data/mockProducts';

// Products always come from the API. Mock data is only a development fallback
// when the server cannot be reached (network error), and never for real API errors.
const canFallback = (err) => USE_MOCK_FALLBACK && err instanceof ApiError && err.status === 0;

export async function fetchProducts(params, signal) {
  try {
    return await api.getProducts(params, signal);
  } catch (err) {
    if (err.name === 'AbortError') throw err;
    if (canFallback(err)) {
      console.warn('[VELORA] API unreachable, using temporary mock products (dev only).');
      return mockProducts;
    }
    throw err;
  }
}

export async function fetchProduct(id, signal) {
  try {
    return await api.getProduct(id, signal);
  } catch (err) {
    if (err.name === 'AbortError') throw err;
    if (canFallback(err)) {
      const found = mockProducts.find((p) => p.id === id);
      if (found) return found;
      throw new ApiError('Product not found', 404);
    }
    throw err;
  }
}
