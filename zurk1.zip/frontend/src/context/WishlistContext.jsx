import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useAuth } from './AuthContext';

// The backend contract has no wishlist endpoints, so the wishlist is stored on this device,
// keyed per user. Swap the read/write helpers for API calls if a wishlist endpoint is added later.
const WishlistContext = createContext(null);

const keyFor = (user) => `velora_wishlist_${user?.id || user?._id || 'guest'}`;
const read = (key) => { try { return JSON.parse(localStorage.getItem(key)) || []; } catch { return []; } };
const write = (key, v) => { try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* ignore */ } };

export function WishlistProvider({ children }) {
  const { user } = useAuth();
  const key = keyFor(user);
  const [items, setItems] = useState(() => read(key));

  useEffect(() => { setItems(read(key)); }, [key]);

  const toggle = useCallback((product) => {
    let added = false;
    setItems((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      added = !exists;
      const next = exists ? prev.filter((p) => p.id !== product.id) : [...prev, product];
      write(key, next);
      return next;
    });
    return added;
  }, [key]);

  const remove = useCallback((id) => {
    setItems((prev) => { const next = prev.filter((p) => p.id !== id); write(key, next); return next; });
  }, [key]);

  const value = useMemo(() => ({
    items, count: items.length, toggle, remove, has: (id) => items.some((p) => p.id === id),
  }), [items, toggle, remove]);

  return <WishlistContext.Provider value={value}>{children}</WishlistContext.Provider>;
}

export const useWishlist = () => useContext(WishlistContext);
