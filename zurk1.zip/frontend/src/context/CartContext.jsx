import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);
const GUEST_KEY = 'velora_guest_cart';

const readGuest = () => {
  try { return JSON.parse(localStorage.getItem(GUEST_KEY)) || []; } catch { return []; }
};
const writeGuest = (items) => {
  try { localStorage.setItem(GUEST_KEY, JSON.stringify(items)); } catch { /* ignore */ }
};

export function CartProvider({ children }) {
  const { user, loading: authLoading } = useAuth();
  const [items, setItems] = useState(readGuest);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadServerCart = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setItems(await api.getCart());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // When a user signs in: push any guest items to the server, then load the server cart.
  useEffect(() => {
    if (authLoading) return;
    if (!user) { setItems(readGuest()); return; }
    (async () => {
      const guest = readGuest();
      try {
        for (const g of guest) {
          await api.addToCart({ productId: g.productId, quantity: g.quantity, size: g.size });
        }
        if (guest.length) writeGuest([]);
      } catch { /* keep guest items if sync fails */ }
      loadServerCart();
    })();
  }, [user, authLoading, loadServerCart]);

  const addItem = useCallback(async (product, { quantity = 1, size = '' } = {}) => {
    if (user) {
      const next = await api.addToCart({ productId: product.id, quantity, size });
      if (next) setItems(next); else await loadServerCart();
      return;
    }
    setItems((prev) => {
      const id = `${product.id}-${size}`;
      const existing = prev.find((i) => i.id === id);
      const next = existing
        ? prev.map((i) => (i.id === id ? { ...i, quantity: i.quantity + quantity } : i))
        : [...prev, { id, productId: product.id, product, quantity, size }];
      writeGuest(next);
      return next;
    });
  }, [user, loadServerCart]);

  const updateQuantity = useCallback(async (itemId, quantity) => {
    if (quantity < 1) return;
    if (user) {
      const next = await api.updateCartItem(itemId, { quantity });
      if (next) setItems(next); else await loadServerCart();
      return;
    }
    setItems((prev) => {
      const next = prev.map((i) => (i.id === itemId ? { ...i, quantity } : i));
      writeGuest(next);
      return next;
    });
  }, [user, loadServerCart]);

  const removeItem = useCallback(async (itemId) => {
    if (user) {
      const next = await api.removeCartItem(itemId);
      if (next) setItems(next); else await loadServerCart();
      return;
    }
    setItems((prev) => {
      const next = prev.filter((i) => i.id !== itemId);
      writeGuest(next);
      return next;
    });
  }, [user, loadServerCart]);

  const clearLocal = useCallback(() => { setItems([]); writeGuest([]); }, []);

  const value = useMemo(() => ({
    items,
    loading,
    error,
    count: items.reduce((n, i) => n + i.quantity, 0),
    subtotal: items.reduce((s, i) => s + i.product.price * i.quantity, 0),
    addItem, updateQuantity, removeItem, clearLocal, reload: loadServerCart,
  }), [items, loading, error, addItem, updateQuantity, removeItem, clearLocal, loadServerCart]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export const useCart = () => useContext(CartContext);
