import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, tokenStore } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(Boolean(tokenStore.get()));

  // Restore session from the stored token via GET /api/auth/me
  useEffect(() => {
    if (!tokenStore.get()) return;
    let active = true;
    api.me()
      .then((u) => { if (active) setUser(u); })
      .catch(() => tokenStore.clear())
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const login = useCallback(async (credentials) => {
    const { token, user: u } = await api.login(credentials);
    if (!token) throw new Error('Login failed: no token returned by the server.');
    tokenStore.set(token);
    setUser(u || (await api.me()));
  }, []);

  const register = useCallback(async (payload) => {
    const { token, user: u } = await api.register(payload);
    if (!token) throw new Error('Registration failed: no token returned by the server.');
    tokenStore.set(token);
    setUser(u || (await api.me()));
  }, []);

  const logout = useCallback(() => {
    tokenStore.clear();
    setUser(null);
  }, []);

  const value = useMemo(() => ({
    user, loading, isAuthenticated: Boolean(user), isAdmin: user?.role === 'admin', login, register, logout,
  }), [user, loading, login, register, logout]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
