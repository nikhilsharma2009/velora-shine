# VELORA Frontend

React + Vite + Tailwind CSS + React Router + Lucide. Talks to the separate Node/Express/MongoDB backend.

## Run

```bash
cp .env.example .env     # then edit values
npm install
npm run dev
```

## Environment variables

| Variable | Purpose |
| --- | --- |
| `VITE_API_BASE_URL` | Backend base URL including `/api`, e.g. `http://localhost:5000/api` |
| `VITE_RAZORPAY_KEY_ID` | Razorpay **public** key id only. Never put the secret here. |
| `VITE_USE_MOCK_FALLBACK` | `true` in dev: uses temporary mock products only if the API is unreachable. Set `false` in production. |

## Structure

- `src/api/client.js` centralized API layer (all endpoints, auth header, error handling)
- `src/api/products.js` product fetching with the dev-only mock fallback
- `src/context/` auth, cart, wishlist, toast state
- `src/components/` navbar, footer, product card, loading/empty/error views
- `src/pages/` all pages; `src/pages/admin/` admin dashboard
- `src/data/mockProducts.js` temporary dev data. Delete once the backend is live.

## Backend contract the frontend expects

Agreed endpoints: `GET /products`, `GET /products/:id`, `POST /auth/register`, `POST /auth/login`, `GET /auth/me`, `GET /cart`, `POST /cart`, `PUT /cart/:id`, `DELETE /cart/:id`, `POST /orders/create`, `POST /payments/verify`, `GET /orders/my`.

- Auth responses: `{ token, user }`. The token is sent as `Authorization: Bearer <token>`. `user.role === 'admin'` unlocks `/admin`.
- Products: `_id`, `name`, `price` (INR), `description`, `category` (Rings/Necklaces/Earrings/Bracelets), `gender` (Women/Men/Unisex), `material`, `images[]`, `sizes[]`, `stock`, optional `bestseller`, `isNew`.
- Cart: `POST /cart` body `{ productId, quantity, size }`; `PUT /cart/:id` body `{ quantity }`. Cart item ids are what `:id` refers to. Responses may return the updated cart (`{ items: [...] }`) or nothing; the frontend reloads in that case.
- `POST /orders/create` body `{ items: [{productId, quantity, size}], shippingAddress: {...} }`. Must respond with `{ order, razorpayOrderId, amount (paise), currency }`. The server decides the amount.
- `POST /payments/verify` body `{ orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature }`. The server verifies the signature. The frontend shows success **only** if this call succeeds.

## Needs backend confirmation (not in the agreed list)

- Admin dashboard assumes: `POST /products`, `PUT /products/:id`, `DELETE /products/:id`, `GET /orders` (all orders), `PUT /orders/:id/status` body `{ status }`. Adjust in `src/api/client.js` if different. Enforce admin role server-side.
- Wishlist and newsletter have no endpoints, so they are stored in the browser (localStorage) for now. Both are isolated in one place each (`WishlistContext.jsx`, `Newsletter.jsx`) for easy swapping.
- Product photos in mock data and the homepage use Unsplash placeholders. Replace with your own photography.
